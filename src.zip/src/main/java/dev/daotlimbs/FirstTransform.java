package dev.daotlimbs;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.SubtitleS2CPacket;
import net.minecraft.network.packet.s2c.play.TitleS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * The first time you ever turn into a titan: 10% you control it straight away and the game calls you a master,
 * 90% the titan will not obey you for a while (it staggers and lashes about on its own).
 */
public final class FirstTransform {
    private FirstTransform() {}

    private static final Set<UUID> IN_TITAN = new HashSet<>();
    private static final Map<UUID, Integer> LOST = new HashMap<>();

    public static void tick(MinecraftServer server) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            Entity titan = (p.age % 5 == 0) ? DaotBridge.titanOf(p) : null;

            // detect the moment you become a titan (checked a few times a second)
            if (p.age % 5 == 0) {
                if (titan != null) {
                    if (IN_TITAN.add(p.getUuid()) && !LimbData.flag(p, LimbData.FIRST_TRANSFORM_DONE)) {
                        LimbData.setFlag(p, LimbData.FIRST_TRANSFORM_DONE, true);
                        roll(p, titan);
                    }
                } else {
                    IN_TITAN.remove(p.getUuid());
                    if (LOST.remove(p.getUuid()) != null) p.sendMessage(Text.literal("The titan is calm again.").formatted(Formatting.GRAY), true);
                }
            }

            Integer left = LOST.get(p.getUuid());
            if (left == null) continue;
            Entity t = (titan != null) ? titan : DaotBridge.ridingTitan(p);
            if (t == null || t.isRemoved()) { LOST.remove(p.getUuid()); continue; }
            thrash(p, t, left);
            if (left <= 1) {
                LOST.remove(p.getUuid());
                p.sendMessage(Text.literal("You finally get a grip on your titan.").formatted(Formatting.GREEN), true);
            } else {
                LOST.put(p.getUuid(), left - 1);
            }
        }
    }

    private static void roll(ServerPlayerEntity p, Entity titan) {
        if (p.getRandom().nextDouble() < LimbConfig.FIRST_TRANSFORM_MASTER_CHANCE) {
            p.sendMessage(Text.literal("You are a master.").formatted(Formatting.GOLD, Formatting.BOLD), false);
            p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("You are a master").formatted(Formatting.GOLD)));
            p.networkHandler.sendPacket(new SubtitleS2CPacket(Text.literal("The titan obeys you on the very first try").formatted(Formatting.YELLOW)));
            if (p.getWorld() instanceof ServerWorld w) {
                w.playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.2f, 0.8f);
            }
        } else {
            LOST.put(p.getUuid(), LimbConfig.LOST_CONTROL_TICKS);
            p.sendMessage(Text.literal("You can't control it!").formatted(Formatting.DARK_RED, Formatting.BOLD), false);
            p.networkHandler.sendPacket(new TitleS2CPacket(Text.literal("You can't control it!").formatted(Formatting.DARK_RED)));
            net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking.send(p, new dev.daotlimbs.net.LimbNet.FearPayload(80));
        }
    }

    /** The titan fights you: it can barely follow orders and staggers about on its own. */
    private static void thrash(ServerPlayerEntity p, Entity titan, int left) {
        if (titan instanceof LivingEntity le) {
            if (p.age % 10 == 0) le.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 5, false, false, false));
        }
        if (p.age % 10 == 0) p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 30, 4, false, false, false));
        if (p.age % 8 == 0) {
            var r = p.getRandom();
            double a = r.nextDouble() * Math.PI * 2;
            double push = 0.25 + r.nextDouble() * 0.25;
            titan.setVelocity(Math.cos(a) * push, 0.05, Math.sin(a) * push);
            titan.velocityModified = true;
            titan.setYaw(titan.getYaw() + (r.nextFloat() - 0.5f) * 70f);
            if (titan.getWorld() instanceof ServerWorld w) {
                w.playSound(null, titan.getX(), titan.getY(), titan.getZ(), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 0.6f, 0.6f);
                Fx.far(w, Fx.steam(), titan.getPos().add(0, titan.getHeight() * 0.5, 0), 6, Math.max(0.5, titan.getWidth() * 0.4), 0.03);
            }
        }
        if (left % 60 == 0) p.sendMessage(Text.literal("Your titan will not obey you!").formatted(Formatting.RED), true);
    }

    public static void forget(UUID id) {
        IN_TITAN.remove(id);
        LOST.remove(id);
    }
}
