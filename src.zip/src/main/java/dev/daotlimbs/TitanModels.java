package dev.daotlimbs;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtDouble;
import net.minecraft.nbt.NbtFloat;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Block-display models loaded from /daot_limbs_models/*.json (flesh and bone Cart Titan, ice rock).
 * The Cart models were generated from the titan's real Danny's AOT geo model.
 */
public final class TitanModels {
    private TitanModels() {}

    private record Part(String block, float[] t, float[] s, float[] q) {}

    private static final Map<String, List<Part>> CACHE = new HashMap<>();
    /** The Cart Titan's model is about 13 blocks tall. */
    public static final double CART_MODEL_HEIGHT = 13.03;

    private static List<Part> load(String name) {
        return CACHE.computeIfAbsent(name, n -> {
            List<Part> out = new ArrayList<>();
            try (InputStream in = TitanModels.class.getResourceAsStream("/daot_limbs_models/" + n + ".json")) {
                if (in == null) { DaotLimbs.LOGGER.warn("[daot_limbs] missing model {}", n); return out; }
                JsonArray arr = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonArray();
                for (JsonElement el : arr) {
                    JsonObject o = el.getAsJsonObject();
                    out.add(new Part(o.get("b").getAsString(), floats(o.getAsJsonArray("t")), floats(o.getAsJsonArray("s")), floats(o.getAsJsonArray("q"))));
                }
            } catch (Throwable t) {
                DaotLimbs.LOGGER.warn("[daot_limbs] could not load model {}: {}", n, t.toString());
            }
            return out;
        });
    }

    private static float[] floats(JsonArray a) {
        float[] f = new float[a.size()];
        for (int i = 0; i < f.length; i++) f[i] = a.get(i).getAsFloat();
        return f;
    }

    private static String blockId(String key) {
        return switch (key) {
            case "flesh" -> Registries.BLOCK.getId(LimbBlocks.FLESH).toString();
            case "bone" -> Registries.BLOCK.getId(LimbBlocks.BONE).toString();
            case "black" -> "minecraft:black_concrete";
            default -> key.contains(":") ? key : "minecraft:" + key;
        };
    }

    /** Spawns the Cart Titan models around the titan, facing the way it faces. */
    public static List<Entity> spawn(ServerWorld w, Entity titan, String model) {
        double scale = Math.max(0.5, Math.min(2.5, titan.getHeight() / CART_MODEL_HEIGHT));
        float yaw = titan instanceof LivingEntity le ? le.bodyYaw : titan.getYaw();
        return spawnAt(w, titan.getPos(), yaw, model, scale, 0);
    }

    /** Spawns a model with its origin at pos. teleportDuration > 0 makes later moves smooth. */
    public static List<Entity> spawnAt(ServerWorld w, Vec3d pos, float yaw, String model, double scale, int teleportDuration) {
        List<Entity> out = new ArrayList<>();
        for (Part p : load(model)) {
            NbtCompound n = new NbtCompound();
            NbtCompound state = new NbtCompound();
            state.putString("Name", blockId(p.block()));
            n.put("block_state", state);

            NbtCompound tr = new NbtCompound();
            tr.put("left_rotation", list(p.q()));
            tr.put("right_rotation", list(0f, 0f, 0f, 1f));
            tr.put("scale", list((float) (p.s()[0] * scale), (float) (p.s()[1] * scale), (float) (p.s()[2] * scale)));
            tr.put("translation", list((float) (p.t()[0] * scale), (float) (p.t()[1] * scale), (float) (p.t()[2] * scale)));
            n.put("transformation", tr);
            n.putFloat("view_range", 5.0f);
            n.putInt("interpolation_duration", 0);
            n.putInt("teleport_duration", teleportDuration);

            NbtList pl = new NbtList();
            pl.add(NbtDouble.of(pos.x));
            pl.add(NbtDouble.of(pos.y));
            pl.add(NbtDouble.of(pos.z));
            n.put("Pos", pl);
            n.put("Rotation", list(yaw, 0f));

            Entity e = LimbVisuals.spawnDisplay(w, n);
            if (e != null) out.add(e);
        }
        return out;
    }

    private static NbtList list(float... v) {
        NbtList l = new NbtList();
        for (float f : v) l.add(NbtFloat.of(f));
        return l;
    }
}
