package dev.daotlimbs;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtDouble;
import net.minecraft.nbt.NbtFloat;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.*;

/**
 * Regrowth visuals from vanilla block-display entities (textured by our flesh / bone blocks).
 * Each limb is TWO connected segments (upper + lower) bent at the elbow / knee, so it reads as a limb growing out of the body:
 * a white bone grows first, a red flesh layer grows around it, then the bend straightens out while your real skin grows over it
 * (the skin itself is the client scaling your actual skin's limb, see the model mixin).
 * Displays carry a tag; leftovers after a crash are deleted when they load again.
 */
public final class LimbVisuals {
    private LimbVisuals() {}

    private static final String TAG = "daot_limbs_fx";

    private static final class Vis {
        final Entity[] bone = new Entity[2];
        final Entity[] flesh = new Entity[2];
    }

    private static final Map<UUID, Map<Limb, Vis>> ACTIVE = new HashMap<>();
    private static final Set<UUID> LIVE = new HashSet<>();

    public static void init() {
        ServerEntityEvents.ENTITY_LOAD.register((e, w) -> {
            if (e.getCommandTags().contains(TAG) && !LIVE.contains(e.getUuid())) e.discard();
        });
    }

    /** stage 1 = bone grows, 2 = flesh grows, 3 = bend straightens while real skin grows. progress 0..1 within the stage. */
    public static void show(UUID owner, ServerWorld w, Entity body, Limb l, int stage, double progress) {
        Map<Limb, Vis> m = ACTIVE.computeIfAbsent(owner, k -> new EnumMap<>(Limb.class));
        Vis v = m.computeIfAbsent(l, k -> new Vis());

        Vec3d top = LimbManager.Anchors.top(body, l);
        float yaw = body instanceof LivingEntity le ? le.bodyYaw : body.getYaw();
        double s = body.getHeight() / 1.8;
        double len = LimbManager.Anchors.length(body, l);
        double prog = Math.max(0, Math.min(1, progress));
        boolean arm = l.group == Limb.Group.ARM;

        // bend (radians). Arms: elbow bends forward (negative about X). Legs: knee bends backward (positive).
        double bend = stage == 3 ? 1.0 - prog : 1.0;            // straightens as the skin covers it
        double a1 = Math.toRadians((arm ? -12 : -10) * bend);
        double a2 = Math.toRadians((arm ? -55 : 35) * bend);

        double gBone, gFlesh;
        switch (stage) {
            case 1 -> { gBone = prog; gFlesh = 0; }
            case 2 -> { gBone = 1; gFlesh = prog; }
            default -> { gBone = 1; gFlesh = 1; }
        }

        float boneT = (float) (0.07 * s);
        float fleshT = (float) (0.23 * s);
        segments(w, v.bone, top, yaw, LimbBlocks.BONE, boneT, len, a1, a2, gBone);
        if (gFlesh > 0.001) segments(w, v.flesh, top, yaw, LimbBlocks.FLESH, fleshT, len, a1, a2, gFlesh);
    }

    /** Two connected boxes (upper, lower). g = how much of the limb has grown, 0..1. */
    private static void segments(ServerWorld w, Entity[] segs, Vec3d top, float yaw, Block block, float t, double len,
                                 double a1, double a2, double g) {
        double l1 = len * 0.5, l2 = len * 0.5;
        double upper = Math.min(g / 0.5, 1.0) * l1;
        double lower = Math.max(0.0, (g - 0.5) / 0.5) * l2;

        segs[0] = segment(w, segs[0], top, yaw, block, t, Math.max(upper, 0.002), new double[]{0, 0, 0}, a1);

        if (lower > 0.002) {
            // the lower segment hangs from the END of the full upper segment, so the two stay joined
            double px = 0;
            double py = -l1 * Math.cos(a1);
            double pz = -l1 * Math.sin(a1);
            segs[1] = segment(w, segs[1], top, yaw, block, t, lower, new double[]{px, py, pz}, a2);
        } else if (segs[1] != null) {
            kill(segs[1]);
            segs[1] = null;
        }
    }

    /**
     * One box hanging down from `pivot` (in the entity's local frame), rotated about the X axis by `angle`.
     * Display transform = translate * rotate * scale, so the corner offset is rotated by hand.
     */
    private static Entity segment(ServerWorld w, Entity existing, Vec3d origin, float yaw, Block block, float t, double len,
                                  double[] pivot, double angle) {
        double c = Math.cos(angle), sn = Math.sin(angle);
        double ox = -t / 2.0, oy = -len, oz = -t / 2.0;
        double ry = oy * c - oz * sn;
        double rz = oy * sn + oz * c;
        float tx = (float) (pivot[0] + ox);
        float ty = (float) (pivot[1] + ry);
        float tz = (float) (pivot[2] + rz);
        float qx = (float) Math.sin(angle / 2.0);
        float qw = (float) Math.cos(angle / 2.0);

        NbtCompound n = nbt(origin, yaw, block, t, (float) len, tx, ty, tz, qx, qw);
        if (existing == null || existing.isRemoved()) {
            Entity e = EntityType.BLOCK_DISPLAY.create(w);
            if (e == null) return null;
            e.readNbt(n);
            e.addCommandTag(TAG);
            LIVE.add(e.getUuid());
            w.spawnEntity(e);
            return e;
        }
        existing.readNbt(n);
        return existing;
    }

    private static NbtCompound nbt(Vec3d pos, float yaw, Block block, float t, float len,
                                   float tx, float ty, float tz, float qx, float qw) {
        NbtCompound n = new NbtCompound();
        NbtCompound state = new NbtCompound();
        state.putString("Name", Registries.BLOCK.getId(block).toString());
        n.put("block_state", state);

        NbtCompound tr = new NbtCompound();
        tr.put("left_rotation", floats(qx, 0, 0, qw));
        tr.put("right_rotation", floats(0, 0, 0, 1));
        tr.put("scale", floats(t, len, t));
        tr.put("translation", floats(tx, ty, tz));
        n.put("transformation", tr);

        n.putInt("interpolation_duration", 2);
        n.putInt("start_interpolation", 0);
        n.putInt("teleport_duration", 2);

        NbtList p = new NbtList();
        p.add(NbtDouble.of(pos.x));
        p.add(NbtDouble.of(pos.y));
        p.add(NbtDouble.of(pos.z));
        n.put("Pos", p);
        n.put("Rotation", floats(yaw, 0f));
        return n;
    }

    private static NbtList floats(float... v) {
        NbtList l = new NbtList();
        for (float f : v) l.add(NbtFloat.of(f));
        return l;
    }

    /** Spawns a tagged display from raw NBT (used for the big Cart Titan models). */
    public static Entity spawnDisplay(ServerWorld w, NbtCompound n) {
        Entity e = EntityType.BLOCK_DISPLAY.create(w);
        if (e == null) return null;
        e.readNbt(n);
        e.addCommandTag(TAG);
        LIVE.add(e.getUuid());
        w.spawnEntity(e);
        return e;
    }

    public static void discardAll(List<Entity> list) {
        if (list == null) return;
        for (Entity e : list) kill(e);
        list.clear();
    }

    // ---------- cleanup ----------

    public static void clear(UUID owner) {
        Map<Limb, Vis> m = ACTIVE.remove(owner);
        if (m == null) return;
        for (Vis v : m.values()) killAll(v);
    }

    /** Removes the displays of the limbs in the bitmask. */
    public static void clear(UUID owner, int mask) {
        Map<Limb, Vis> m = ACTIVE.get(owner);
        if (m == null) return;
        for (Limb l : Limb.values()) {
            if ((mask & l.bit()) == 0) continue;
            Vis v = m.remove(l);
            if (v != null) killAll(v);
        }
        if (m.isEmpty()) ACTIVE.remove(owner);
    }

    private static void killAll(Vis v) {
        for (Entity e : v.bone) kill(e);
        for (Entity e : v.flesh) kill(e);
    }

    private static void kill(Entity e) {
        if (e == null) return;
        LIVE.remove(e.getUuid());
        e.discard();
    }
}
