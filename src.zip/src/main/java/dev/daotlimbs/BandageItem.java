package dev.daotlimbs;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

/** Anyone can use it. Regrows missing arms and legs (not eyes, not hearts), shown with the flesh/bone blocks, no steam. */
public class BandageItem extends Item {
    public BandageItem(Settings settings) { super(settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!world.isClient && user instanceof ServerPlayerEntity p && LimbManager.armLegLost(p) == 0) {
            p.sendMessage(Text.literal("You have no missing arms or legs.").formatted(Formatting.GRAY), true);
            return TypedActionResult.fail(stack);
        }
        user.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }

    @Override
    public int getMaxUseTime(ItemStack stack, LivingEntity user) { return 40; }

    @Override
    public UseAction getUseAction(ItemStack stack) { return UseAction.BLOCK; }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        if (!world.isClient && user instanceof ServerPlayerEntity p) {
            if (LimbManager.startBandage(p) && !p.isCreative()) stack.decrement(1);
        }
        return stack;
    }
}
