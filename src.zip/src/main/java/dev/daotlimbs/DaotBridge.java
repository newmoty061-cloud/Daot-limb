package dev.daotlimbs;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Every touch point with Danny's AOT lives here, and all of it is reflective, so this addon compiles without the
 * mod's jar and a missing/renamed member only disables ONE feature (it logs once) instead of crashing.
 * If a future DAOT update renames something, this is the only file to fix.
 */
public final class DaotBridge {
    private DaotBridge() {}

    private static final Set<String> WARNED = new HashSet<>();

    private static Class<?> cls(String name) {
        try { return Class.forName(name); }
        catch (Throwable t) { warn("class " + name, t); return null; }
    }

    private static Method method(String cn, String mn, Class<?>... params) {
        Class<?> c = cls(cn);
        if (c == null) return null;
        try { return c.getMethod(mn, params); }
        catch (Throwable t) { warn(cn + "#" + mn, t); return null; }
    }

    private static void warn(String what, Throwable t) {
        if (WARNED.add(what)) DaotLimbs.LOGGER.warn("[daot_limbs] Could not resolve {} ({}). The related feature is disabled.", what, t.toString());
    }

    // ---------- cached lookups ----------
    private static Method anyHeldBy, isDismounting, getShifterUUID, isPureTitan, isBeheaded;
    private static Class<?> shifterTitanClass;
    private static boolean resolved;

    private static void resolve() {
        if (resolved) return;
        resolved = true;
        anyHeldBy = method("daot.TitanPowerType", "anyHeldBy", PlayerEntity.class);
        shifterTitanClass = cls("daot.ShifterTitan");
        if (shifterTitanClass != null) {
            try { isDismounting = shifterTitanClass.getMethod("isDismounting"); } catch (Throwable t) { warn("ShifterTitan#isDismounting", t); }
            try { getShifterUUID = shifterTitanClass.getMethod("getShifterUUID"); } catch (Throwable t) { warn("ShifterTitan#getShifterUUID", t); }
        }
        isPureTitan = method("daot.TitanPowerHelper", "isPureTitan", Entity.class);
        isBeheaded = method("daot.Decapitation", "isBeheaded", Entity.class);
    }

    private static boolean callBool(Method m, Object target, Object... args) {
        if (m == null) return false;
        try { return Boolean.TRUE.equals(m.invoke(target, args)); }
        catch (Throwable t) { warn(m.getName(), t); return false; }
    }

    // ---------- public API ----------

    /** Does this player currently hold any of the nine titan powers? */
    public static boolean isShifter(PlayerEntity p) {
        resolve();
        return callBool(anyHeldBy, null, p);
    }

    public static boolean isShifterTitan(Entity e) {
        resolve();
        return shifterTitanClass != null && shifterTitanClass.isInstance(e);
    }

    public static boolean isDismounting(Entity e) {
        resolve();
        return isShifterTitan(e) && callBool(isDismounting, e);
    }

    public static boolean isPureTitan(Entity e) {
        resolve();
        return callBool(isPureTitan, null, e);
    }

    public static boolean isBeheaded(Entity e) {
        resolve();
        return callBool(isBeheaded, null, e);
    }

    public static boolean isColossal(Entity e) {
        return e.getClass().getSimpleName().contains("Colossal");
    }

    private static Object call(Object target, String name, Class<?>[] types, Object... args) {
        try {
            Method m = target.getClass().getMethod(name, types);
            return m.invoke(target, args);
        } catch (Throwable t) {
            warn(target.getClass().getSimpleName() + "#" + name, t);
            return null;
        }
    }

    /** Armored Titan only: DAOT's own "legs shattered" state. No-op for other titans. */
    public static void setTitanLegsShattered(Entity titan, boolean shattered) {
        if (titan.getClass().getSimpleName().contains("Armored")) call(titan, "setLegsShattered", new Class<?>[]{boolean.class}, shattered);
    }

    public static boolean isTitanBlinded(Entity titan) {
        return Boolean.TRUE.equals(call(titan, "isBlinded", new Class<?>[0]));
    }

    /** DAOT's own titan blindness behaviour. */
    public static void blindTitan(Entity titan) {
        call(titan, "triggerBlindness", new Class<?>[0]);
    }

    /** The shifter titan the player is currently riding/controlling, or null when in human form. */
    public static Entity ridingTitan(ServerPlayerEntity p) {
        Entity v = p.getVehicle();
        return (v != null && isShifterTitan(v)) ? v : null;
    }

    public static boolean isCart(Entity e) {
        return e.getClass().getSimpleName().contains("Cart");
    }

    /**
     * The shifter titan this player is in: the one they ride, or failing that the one that names them as its shifter.
     * (The search is only done on demand, e.g. while the player holds Shift.)
     */
    public static Entity titanOf(ServerPlayerEntity p) {
        Entity ride = ridingTitan(p);
        if (ride != null) return ride;
        resolve();
        if (getShifterUUID == null) return null;
        for (Entity e : p.getWorld().getOtherEntities(null, p.getBoundingBox().expand(48), x -> isShifterTitan(x) && x.isAlive())) {
            try {
                if (p.getUuid().equals(getShifterUUID.invoke(e)) && !isDismounting(e)) return e;
            } catch (Throwable t) { warn("getShifterUUID search", t); return null; }
        }
        return null;
    }

    /** Calls DAOT's own transform-key handler (which, while in a titan, makes you climb out). */
    public static boolean triggerTitanShift(ServerPlayerEntity p) {
        Class<?> c = cls("daot.network.ModNetworking");
        if (c == null) return false;
        try {
            Method m = c.getDeclaredMethod("handleTitanShift", ServerPlayerEntity.class, ServerWorld.class);
            m.setAccessible(true);
            m.invoke(null, p, p.getServerWorld());
            return true;
        } catch (Throwable t) { warn("ModNetworking#handleTitanShift", t); return false; }
    }

    /** Fallback: DAOT's own "release all titans of this player". */
    public static boolean releaseTitans(ServerPlayerEntity p) {
        Class<?> c = cls("daot.network.ModNetworking");
        if (c == null) return false;
        try {
            Method m = c.getDeclaredMethod("releaseAllTitans", ServerPlayerEntity.class);
            m.setAccessible(true);
            m.invoke(null, p);
            return true;
        } catch (Throwable t) { warn("ModNetworking#releaseAllTitans", t); return false; }
    }

    /** Beast Titan: drop whatever rock it is holding / about to throw. */
    public static void cancelRockThrow(Entity titan) {
        call(titan, "cancelRockThrow", new Class<?>[0]);
    }

    /** The player who owns this shifter titan, or null. */
    public static ServerPlayerEntity shifterOf(Entity titan, MinecraftServer server) {
        resolve();
        if (!isShifterTitan(titan) || getShifterUUID == null) return null;
        try {
            Object u = getShifterUUID.invoke(titan);
            return u instanceof UUID id ? server.getPlayerManager().getPlayer(id) : null;
        } catch (Throwable t) { warn("getShifterUUID call", t); return null; }
    }

    /** DAOT's private static pendingShifts map (key -> PendingShift record), or null. */
    @SuppressWarnings("unchecked")
    public static Map<Object, Object> pendingShifts() {
        Class<?> c = cls("daot.network.ModNetworking");
        if (c == null) return null;
        try {
            Field f = c.getDeclaredField("pendingShifts");
            f.setAccessible(true);
            return (Map<Object, Object>) f.get(null);
        } catch (Throwable t) { warn("ModNetworking.pendingShifts", t); return null; }
    }
}
