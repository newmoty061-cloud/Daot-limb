package dev.daotlimbs.mixin;

import dev.daotlimbs.LimbConfig;
import dev.daotlimbs.LimbRules;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Players' hearts only heal through the Hearts menu option (BLOCK_ALL_HEALING).
 * Food regeneration is always blocked. Mobs and titans are never touched.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Inject(method = "heal", at = @At("HEAD"), cancellable = true)
    private void daotlimbs$noHeal(float amount, CallbackInfo ci) {
        if (LimbRules.suppressHeal) {
            ci.cancel();
            return;
        }
        if (LimbConfig.BLOCK_ALL_HEALING && !LimbRules.allowHeal && (Object) this instanceof PlayerEntity) {
            ci.cancel();
        }
    }
}
