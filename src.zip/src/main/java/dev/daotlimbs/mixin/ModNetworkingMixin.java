package dev.daotlimbs.mixin;

import dev.daotlimbs.DaotBridge;
import dev.daotlimbs.HoldGate;
import dev.daotlimbs.LimbConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Danny's AOT: the transform key handler. While you are inside a titan it would climb you out straight away.
 * With HOLD_TO_LEAVE_TITAN it is blocked unless our 5-second Shift hold let it through.
 */
@Mixin(targets = "daot.network.ModNetworking", remap = false)
public abstract class ModNetworkingMixin {
    @Inject(method = "handleTitanShift", at = @At("HEAD"), cancellable = true, remap = false)
    private static void daotlimbs$holdToLeave(ServerPlayerEntity player, ServerWorld world, CallbackInfo ci) {
        if (!LimbConfig.HOLD_TO_LEAVE_TITAN) return;
        if (DaotBridge.titanOf(player) == null) return;      // not in a titan: normal transformation
        if (HoldGate.consume(player)) return;                // our hold opened the gate
        ci.cancel();
        player.sendMessage(Text.literal("Hold Shift for 5 seconds to leave your titan.").formatted(Formatting.GRAY), true);
    }

    /** Danny's AOT heals shifters on its own; with BLOCK_SHIFTER_REGEN only the Hearts menu option heals. */
    @Inject(method = "tickShifterRegeneration", at = @At("HEAD"), cancellable = true, remap = false)
    private static void daotlimbs$noShifterRegen(MinecraftServer server, CallbackInfo ci) {
        if (LimbConfig.BLOCK_SHIFTER_REGEN) ci.cancel();
    }
}
