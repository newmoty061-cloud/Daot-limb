package dev.daotlimbs.mixin;

import dev.daotlimbs.LimbConfig;
import dev.daotlimbs.LimbRules;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Marks the window in which vanilla's food-based regeneration runs, so it can be blocked. */
@Mixin(HungerManager.class)
public abstract class HungerManagerMixin {
    @Inject(method = "update", at = @At("HEAD"))
    private void daotlimbs$begin(PlayerEntity player, CallbackInfo ci) {
        if (LimbConfig.DISABLE_NATURAL_REGEN) LimbRules.suppressHeal = true;
    }

    @Inject(method = "update", at = @At("RETURN"))
    private void daotlimbs$end(PlayerEntity player, CallbackInfo ci) {
        LimbRules.suppressHeal = false;
    }
}
