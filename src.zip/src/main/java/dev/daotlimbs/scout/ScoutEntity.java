package dev.daotlimbs.scout;

import dev.daotlimbs.DaotBridge;
import dev.daotlimbs.DaotLimbs;
import dev.daotlimbs.LimbConfig;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.FleeEntityGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * A scout of one of the three regiments. 300 skins (100 per regiment), a random personality and name,
 * and they talk to nearby players. Only ever spawned in Paradise (see ScoutSpawner).
 */
public class ScoutEntity extends PathAwareEntity {
    public static EntityType<ScoutEntity> TYPE;

    private static final TrackedData<Integer> VARIANT = DataTracker.registerData(ScoutEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> PERSONALITY = DataTracker.registerData(ScoutEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> BLOODLINE = DataTracker.registerData(ScoutEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private int ambientCooldown = 100;
    private int alarmCooldown = 0;
    private int chatterCooldown = 200;

    // ---- extras: ODM gear, elders and secret titan powers ----
    private boolean extrasRolled = false;
    private boolean elder = false;
    private int power = -1;          // index into ScoutLore.Power, -1 = none
    private boolean hiding = false;  // true = secretly holds a titan power

    public ScoutEntity(EntityType<? extends ScoutEntity> type, World world) {
        super(type, world);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(VARIANT, 0);
        builder.add(PERSONALITY, 0);
        builder.add(BLOODLINE, 0);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return PathAwareEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.26)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 24.0);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(0, new SwimGoal(this));
        this.goalSelector.add(1, new FleeEntityGoal<>(this, HostileEntity.class, 14.0f, 1.0, 1.35));
        this.goalSelector.add(5, new WanderAroundFarGoal(this, 0.8));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason spawnReason, @Nullable EntityData entityData) {
        EntityData data = super.initialize(world, difficulty, spawnReason, entityData);
        int reg = this.random.nextInt(3);
        int design = this.random.nextInt(100);
        this.dataTracker.set(VARIANT, reg * 100 + design);
        this.dataTracker.set(PERSONALITY, this.random.nextInt(ScoutDialogue.Personality.values().length));
        this.setCustomName(Text.literal(ScoutDialogue.randomName(this.random)));
        this.setPersistent();
        this.setCanPickUpLoot(false);                       // they never pick anything up; their gear is given in rollExtras

        ScoutDialogue.Bloodline blood = ScoutDialogue.Bloodline.roll(this.random);
        this.dataTracker.set(BLOODLINE, blood.ordinal());
        if (blood == ScoutDialogue.Bloodline.ACKERMAN) {
            this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(30.0);
            this.getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.34);
        } else if (blood == ScoutDialogue.Bloodline.ROYAL) {
            this.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(24.0);
        }
        this.setHealth(this.getMaxHealth());
        rollExtras();
        return data;
    }

    // =====================================================================================================
    // ODM gear, elders, secret powers
    // =====================================================================================================

    /** Gives the scout ODM gear and maybe makes them an elder (once per scout, also fixes scouts from older saves). */
    private void rollExtras() {
        extrasRolled = true;
        equipGear();
        if (this.random.nextInt(100) < LimbConfig.SCOUT_ELDER_PERCENT) {
            elder = true;
            this.setCustomName(Text.literal("Elder " + baseName()));
            if (this.random.nextInt(100) < LimbConfig.ELDER_POWER_PERCENT) {
                power = this.random.nextInt(ScoutLore.Power.values().length);
                hiding = this.random.nextInt(100) < LimbConfig.ELDER_HIDE_PERCENT;
            }
        }
    }

    private void equipGear() {
        give(EquipmentSlot.MAINHAND, "blade");
        give(EquipmentSlot.OFFHAND, "blade");
        give(EquipmentSlot.CHEST, "odm_harness");
        give(EquipmentSlot.LEGS, "odm_gear");
        give(EquipmentSlot.FEET, "odm_boots");
    }

    private void give(EquipmentSlot slot, String id) {
        Optional<Item> item = Registries.ITEM.getOrEmpty(Identifier.of("dannys-aot", id));
        if (item.isEmpty()) {
            DaotLimbs.LOGGER.warn("[daot_limbs] item dannys-aot:{} not found; scouts will not carry it", id);
            return;
        }
        this.equipStack(slot, new ItemStack(item.get()));
        this.setEquipmentDropChance(slot, 0.0f);            // killing a scout does not hand out free gear
    }

    private ScoutLore.Power powerType() {
        ScoutLore.Power[] all = ScoutLore.Power.values();
        return (power >= 0 && power < all.length) ? all[power] : null;
    }

    private boolean holdsPower() { return elder && powerType() != null; }

    /** The name without the "Elder " prefix. */
    private String baseName() {
        String n = nameText();
        return n.startsWith("Elder ") ? n.substring(6) : n;
    }

    private String firstName() {
        String b = baseName();
        int sp = b.indexOf(' ');
        return sp < 0 ? b : b.substring(0, sp);
    }

    /** True if the player's chat message names this scout (first name, full name, or "elder" for elders). */
    public boolean isAddressedBy(Set<String> words) {
        String first = firstName().toLowerCase(java.util.Locale.ROOT);
        return (first.length() >= 3 && words.contains(first)) || (elder && words.contains("elder"));
    }

    /** The secret comes out. Nearby scouts react a moment later. */
    private void reveal() {
        hiding = false;
        MinecraftServer srv = this.getServer();
        if (srv == null || !(this.getWorld() instanceof ServerWorld w)) return;
        List<ScoutEntity> others = w.getEntitiesByType(ScoutEntity.TYPE, this.getBoundingBox().expand(10), e -> e != this && e.isAlive());
        if (others.isEmpty()) return;
        ScoutEntity witness = others.get(this.random.nextInt(others.size()));
        ScoutChat.later(srv, 50, () -> {
            if (!witness.isRemoved() && witness.isAlive()) witness.broadcast(ScoutLore.pick(ScoutLore.SHOCK, witness.random), 24);
        });
    }

    /** What this scout answers to something a player typed. */
    public String replyToChat(String lower, Set<String> words) {
        boolean you = words.contains("you") || words.contains("your") || words.contains("u");
        boolean titanTalk = words.contains("titan") || words.contains("titans") || words.contains("shifter") || words.contains("shifters")
                || words.contains("power") || words.contains("transform") || lower.contains("turn into");
        if (you && titanTalk) {
            ScoutLore.Power p = powerType();
            if (!holdsPower()) return ScoutLore.pick(ScoutLore.NOT_A_SHIFTER, this.random);
            if (!hiding) return String.format(ScoutLore.pick(ScoutLore.ADMIT, this.random), p.title);
            if (this.random.nextInt(100) < LimbConfig.ELDER_SLIP_PERCENT) {
                reveal();
                return String.format(ScoutLore.pick(ScoutLore.SLIP, this.random), p.title);
            }
            return ScoutLore.pick(ScoutLore.DENY, this.random);
        }
        if (words.contains("hello") || words.contains("hi") || words.contains("hey") || words.contains("greetings") || words.contains("morning")
                || words.contains("evening") || words.contains("yo") || words.contains("sup")) {
            return ScoutLore.pick(ScoutLore.GREET[getPersonality().ordinal()], this.random);
        }
        if (lower.contains("how are you") || lower.contains("how's it going") || lower.contains("hows it going") || lower.contains("how r u")) {
            return ScoutLore.pick(ScoutLore.HOW_ARE_YOU[getPersonality().ordinal()], this.random);
        }
        if (lower.contains("who are you") || lower.contains("your name") || words.contains("name")) {
            return String.format(ScoutLore.pick(ScoutLore.WHO_AM_I, this.random), nameText(), getRegiment().title);
        }
        if (words.contains("odm") || words.contains("gear") || words.contains("blade") || words.contains("blades") || words.contains("gas")) {
            return ScoutLore.pick(ScoutLore.GEAR, this.random);
        }
        if (words.contains("wall") || words.contains("walls") || words.contains("paradise") || words.contains("paradis")) {
            return ScoutLore.pick(ScoutLore.WALL, this.random);
        }
        if (words.contains("thanks") || words.contains("thank") || words.contains("thx")) {
            return ScoutLore.pick(ScoutLore.THANKS, this.random);
        }
        if (words.contains("help") || words.contains("danger") || words.contains("run")) {
            return ScoutLore.pick(ScoutLore.HELP, this.random);
        }
        return ScoutDialogue.chatLine(getRegiment(), getPersonality(), getBloodline(), this.random);
    }

    /** Scout-to-scout small talk. Only happens when a player is around to overhear. */
    private void chatter() {
        MinecraftServer srv = this.getServer();
        if (srv == null || !(this.getWorld() instanceof ServerWorld w)) return;
        if (w.getClosestPlayer(this, 20.0) == null) return;
        List<ScoutEntity> others = w.getEntitiesByType(ScoutEntity.TYPE, this.getBoundingBox().expand(6), e -> e != this && e.isAlive());
        if (others.isEmpty()) return;
        ScoutEntity other = others.get(this.random.nextInt(others.size()));

        this.getLookControl().lookAt(other);
        other.getLookControl().lookAt(this);

        String line;
        String answer;
        int roll = this.random.nextInt(3);
        if (other.holdsPower() && other.hiding && roll == 0) {
            line = ScoutLore.pick(ScoutLore.RUMOUR_TO_ELDER, this.random);
            if (other.random.nextInt(100) < LimbConfig.ELDER_SLIP_PERCENT / 2) {
                answer = String.format(ScoutLore.pick(ScoutLore.SLIP, other.random), other.powerType().title);
                other.reveal();
            } else {
                answer = ScoutLore.pick(ScoutLore.DENY, other.random);
            }
        } else if (other.holdsPower() && !other.hiding && roll == 0) {
            line = ScoutLore.pick(ScoutLore.ASK_ELDER, this.random);
            answer = String.format(ScoutLore.pick(ScoutLore.OPEN_AMBIENT, other.random), other.powerType().title);
        } else {
            line = other.firstName() + ", " + ScoutLore.pick(ScoutLore.TO_COLLEAGUE, this.random);
            answer = ScoutLore.pick(ScoutLore.REPLY[other.getPersonality().ordinal()], other.random);
        }
        this.broadcast(line, 24);
        final String reply = answer;
        ScoutChat.later(srv, 45 + this.random.nextInt(30), () -> {
            if (!other.isRemoved() && other.isAlive()) other.broadcast(reply, 24);
        });
    }

    public int getVariant() { return this.dataTracker.get(VARIANT); }

    public ScoutDialogue.Regiment getRegiment() {
        return ScoutDialogue.Regiment.values()[Math.max(0, Math.min(2, getVariant() / 100))];
    }

    public ScoutDialogue.Personality getPersonality() {
        ScoutDialogue.Personality[] all = ScoutDialogue.Personality.values();
        return all[Math.max(0, Math.min(all.length - 1, this.dataTracker.get(PERSONALITY)))];
    }

    public ScoutDialogue.Bloodline getBloodline() {
        ScoutDialogue.Bloodline[] all = ScoutDialogue.Bloodline.values();
        return all[Math.max(0, Math.min(all.length - 1, this.dataTracker.get(BLOODLINE)))];
    }

    /** texture for variant 0..299: three regiments x 100 designs */
    public static Identifier texture(int variant) {
        int v = Math.max(0, Math.min(299, variant));
        ScoutDialogue.Regiment reg = ScoutDialogue.Regiment.values()[v / 100];
        return Identifier.of(DaotLimbs.MOD_ID, String.format("textures/entity/scout/%s_%03d.png", reg.code, v % 100));
    }

    private static String capitalize(String s) {
        return s.isEmpty() ? s : s.charAt(0) + s.substring(1).toLowerCase();
    }

    private String nameText() {
        return this.hasCustomName() ? this.getCustomName().getString() : "Scout";
    }

    /** Says a line to every player within range. */
    public void broadcast(String line, double range) {
        for (PlayerEntity pl : this.getWorld().getPlayers()) {
            if (pl instanceof ServerPlayerEntity sp && sp.squaredDistanceTo(this) <= range * range) {
                ScoutDialogue.say(nameText(), getRegiment(), sp, line);
            }
        }
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        if (!this.getWorld().isClient && player instanceof ServerPlayerEntity sp) {
            if (player.isSneaking()) {      // sneak + use: who is this?
                String info = nameText() + " - " + getRegiment().title + " - " + capitalize(getPersonality().name())
                        + " - " + getBloodline().title + " blood";
                if (elder) info += " - Elder";
                if (holdsPower() && !hiding) info += " - holds the " + powerType().title;   // a hidden power is never shown
                sp.sendMessage(Text.literal(info), false);
            } else if (holdsPower() && hiding && this.random.nextInt(8) == 0) {
                ScoutDialogue.say(nameText(), getRegiment(), sp, ScoutLore.pick(ScoutLore.HINT, this.random));
            } else {
                ScoutDialogue.say(nameText(), getRegiment(), sp, ScoutDialogue.chatLine(getRegiment(), getPersonality(), getBloodline(), this.random));
            }
            this.getLookControl().lookAt(player);
        }
        return ActionResult.success(this.getWorld().isClient);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient || this.age % 20 != 0) return;
        if (!extrasRolled) rollExtras();                    // scouts saved before this feature existed

        if (alarmCooldown > 0) alarmCooldown -= 20;
        if (alarmCooldown <= 0) {
            List<LivingEntity> titans = this.getWorld().getEntitiesByClass(LivingEntity.class, this.getBoundingBox().expand(22),
                    e -> e.isAlive() && (DaotBridge.isPureTitan(e) || DaotBridge.isShifterTitan(e)));
            if (!titans.isEmpty()) {
                if (holdsPower()) {
                    String t = powerType().title;
                    if (!hiding) {
                        broadcast(String.format(ScoutLore.pick(ScoutLore.OPEN_ALARM, this.random), t), 24);
                        alarmCooldown = 400;
                        return;
                    }
                    if (this.random.nextInt(2) == 0) {            // the secret slips out under pressure
                        reveal();
                        broadcast(String.format(ScoutLore.pick(ScoutLore.SLIP_ALARM, this.random), t), 24);
                        alarmCooldown = 400;
                        return;
                    }
                }
                broadcast(ScoutDialogue.alarmLine(getPersonality(), this.random), 24);
                alarmCooldown = 400;
                return;
            }
        }

        ambientCooldown -= 20;
        if (ambientCooldown <= 0) {
            PlayerEntity near = this.getWorld().getClosestPlayer(this, 8.0);
            if (near instanceof ServerPlayerEntity sp) {
                String line;
                if (holdsPower() && !hiding && this.random.nextInt(3) == 0) line = String.format(ScoutLore.pick(ScoutLore.OPEN_AMBIENT, this.random), powerType().title);
                else if (holdsPower() && hiding && this.random.nextInt(8) == 0) line = ScoutLore.pick(ScoutLore.HINT, this.random);
                else line = ScoutDialogue.chatLine(getRegiment(), getPersonality(), getBloodline(), this.random);
                ScoutDialogue.say(nameText(), getRegiment(), sp, line);
            }
            ambientCooldown = 300 + this.random.nextInt(500);
        }

        chatterCooldown -= 20;
        if (chatterCooldown <= 0) {
            chatterCooldown = LimbConfig.SCOUT_CHATTER_MIN_TICKS + this.random.nextInt(LimbConfig.SCOUT_CHATTER_MIN_TICKS);
            chatter();
        }
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("ScoutVariant", getVariant());
        nbt.putInt("ScoutPersonality", this.dataTracker.get(PERSONALITY));
        nbt.putInt("ScoutBloodline", this.dataTracker.get(BLOODLINE));
        nbt.putBoolean("ScoutExtras", extrasRolled);
        nbt.putBoolean("ScoutElder", elder);
        nbt.putInt("ScoutPower", power);
        nbt.putBoolean("ScoutHiding", hiding);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        this.dataTracker.set(VARIANT, nbt.getInt("ScoutVariant"));
        this.dataTracker.set(PERSONALITY, nbt.getInt("ScoutPersonality"));
        this.dataTracker.set(BLOODLINE, nbt.getInt("ScoutBloodline"));
        extrasRolled = nbt.getBoolean("ScoutExtras");
        elder = nbt.getBoolean("ScoutElder");
        power = nbt.contains("ScoutPower") ? nbt.getInt("ScoutPower") : -1;
        hiding = nbt.getBoolean("ScoutHiding");
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) { return false; }
}
