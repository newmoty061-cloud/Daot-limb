package dev.daotlimbs;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;

import java.util.Optional;
import java.util.Random;

/**
 * A player's very first join: they start in a random city of Danny's AOT's own Paradise dimension (dannys-aot:paradis),
 * with a chest beside them holding a full set of ODM gear and 4 spare blades.
 */
public final class FirstSpawn {
    private FirstSpawn() {}

    public static final Identifier PARADIS = Identifier.of("dannys-aot", "paradis");

    public static void init() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                server.execute(() -> run(handler.getPlayer(), server)));
    }

    private static void run(ServerPlayerEntity p, MinecraftServer server) {
        if (p == null || p.isRemoved() || LimbData.flag(p, LimbData.FIRST_SPAWN_DONE)) return;
        ServerWorld w = server.getWorld(RegistryKey.of(RegistryKeys.WORLD, PARADIS));
        if (w == null) {
            DaotLimbs.LOGGER.warn("[daot_limbs] Paradise dimension {} not found; skipping the first-spawn teleport.", PARADIS);
            return;
        }

        int[] c = pickCity(w);
        w.getChunk(c[0] >> 4, c[1] >> 4);                          // generate / load the chunk
        int y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, c[0], c[1]);
        BlockPos stand = new BlockPos(c[0], y, c[1]);

        // chest two blocks away, on the ground
        BlockPos chestPos = stand.east(2);
        w.getChunk(chestPos.getX() >> 4, chestPos.getZ() >> 4);
        BlockPos cp = new BlockPos(chestPos.getX(), w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, chestPos.getX(), chestPos.getZ()), chestPos.getZ());
        w.setBlockState(cp, Blocks.CHEST.getDefaultState());
        if (w.getBlockEntity(cp) instanceof ChestBlockEntity chest) fill(chest);

        p.teleport(w, stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5, p.getYaw(), 0f);
        p.setSpawnPoint(w.getRegistryKey(), stand, 0f, true, false);
        LimbData.setFlag(p, LimbData.FIRST_SPAWN_DONE, true);
        p.sendMessage(Text.literal("You wake up inside the walls. A chest nearby holds your gear.").formatted(Formatting.GOLD), false);
    }

    /** One random district / city centre of the Paradise dimension, from the mod's own generator. */
    private static int[] pickCity(ServerWorld w) {
        Random r = new Random();
        try {
            Class<?> g = Class.forName("daot.world.ParadisChunkGenerator");
            int[][] centers = (int[][]) g.getMethod("getAllDistrictCenters").invoke(null);
            if (centers != null && centers.length > 0) {
                int[] c = centers[r.nextInt(centers.length)];
                if (c != null && c.length >= 2) return new int[]{c[0], c[1]};
            }
        } catch (Throwable t) {
            DaotLimbs.LOGGER.warn("[daot_limbs] could not read Paradise city centres: {}", t.toString());
        }
        try {                                                       // fallback: the big city's own centre
            Class<?> g = Class.forName("daot.world.ParadisChunkGenerator");
            var fx = g.getDeclaredField("CITY_CENTER_X"); fx.setAccessible(true);
            var fz = g.getDeclaredField("CITY_CENTER_Z"); fz.setAccessible(true);
            return new int[]{fx.getInt(null), fz.getInt(null)};
        } catch (Throwable t) {
            return new int[]{0, 0};
        }
    }

    private static void fill(ChestBlockEntity chest) {
        int slot = 0;
        slot = put(chest, slot, "odm_harness", 1);
        slot = put(chest, slot, "odm_gear", 1);
        slot = put(chest, slot, "odm_boots", 1);
        slot = put(chest, slot, "gas_canister", 4);
        slot = put(chest, slot, "blade", 2);     // the two you fight with
        put(chest, slot, "blade", 4);            // 4 replacements
    }

    private static int put(ChestBlockEntity chest, int slot, String id, int count) {
        Optional<Item> item = Registries.ITEM.getOrEmpty(Identifier.of("dannys-aot", id));
        if (item.isEmpty()) {
            DaotLimbs.LOGGER.warn("[daot_limbs] item dannys-aot:{} not found for the starter chest", id);
            return slot;
        }
        chest.setStack(slot, new ItemStack(item.get(), count));
        return slot + 1;
    }
}
