package dev.daotlimbs.mixin.client;

import dev.daotlimbs.Limb;
import dev.daotlimbs.client.ClientLimbState;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Missing arm/leg: hidden. While it regrows, the limb comes back as YOUR real skin, stretching out from the body
 * (the model is shared between all players, so scales are reset on every call).
 */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void daotlimbs$hideOrGrowLimbs(LivingEntity entity, float f, float g, float h, float i, float j, CallbackInfo ci) {
        PlayerEntityModel<?> m = (PlayerEntityModel<?>) (Object) this;
        m.leftArm.yScale = 1f; m.leftSleeve.yScale = 1f;
        m.rightArm.yScale = 1f; m.rightSleeve.yScale = 1f;
        m.leftLeg.yScale = 1f; m.leftPants.yScale = 1f;
        m.rightLeg.yScale = 1f; m.rightPants.yScale = 1f;

        int id = entity.getId();
        int mask = ClientLimbState.get(id);
        if (mask == 0) return;
        apply(m.leftArm, m.leftSleeve, mask, id, Limb.LEFT_ARM);
        apply(m.rightArm, m.rightSleeve, mask, id, Limb.RIGHT_ARM);
        apply(m.leftLeg, m.leftPants, mask, id, Limb.LEFT_LEG);
        apply(m.rightLeg, m.rightPants, mask, id, Limb.RIGHT_LEG);
    }

    private static void apply(ModelPart part, ModelPart layer, int mask, int id, Limb limb) {
        if ((mask & limb.bit()) == 0) return;
        float grow = ClientLimbState.getGrow(id, limb.ordinal());
        if (grow <= 0.001f) {
            part.visible = false;
            layer.visible = false;
        } else {
            part.visible = true;
            layer.visible = true;
            part.yScale = grow;
            layer.yScale = grow;
        }
    }
}
